

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
char nome[20];
    setlocale (LC_ALL,"portuguese");
    cout << "Digite o seu nome: \n";
    cin>> nome;
    cout << "você se chama: "<< nome << endl;

    return 0;
}

