

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float n1,n2,n3,soma,media;
    cout <<"digite o primeiro numero\n:";
    cin>>n1;
    cout << "digite o segundo numero\n:";
    cin >> n2;
    cout<<  "digite o terceiro numero:\n";
    cin >> n3;
    soma= n1+n2+n3;
    media=soma/3;
    cout << "o valor da soma é:\n "<<soma;
    cout<< "o valor da media é: "<<media<< endl;
    
    return 0;
}

