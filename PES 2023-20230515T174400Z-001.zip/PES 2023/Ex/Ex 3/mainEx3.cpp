#include <iostream>
using namespace std;

int main() 
{
    float fahrenheit, celsius;
    cout << "Insira valor fahrenheit: ";
    cin >> fahrenheit;
    celsius = (fahrenheit - 32) * (5.0/9.0);
    cout << "O valor em celsius e: " << celsius;

    return 0;
}
