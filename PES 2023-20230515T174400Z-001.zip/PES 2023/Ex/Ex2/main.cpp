
#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    char nome [20];
    int nota1, nota2, nota3, media;
    cout << "Digite seu nome: " <<endl;
        cin >> nome;
    cout << "Digite a nota 1: " <<endl;
        cin>> nota1;
    cout << "Digite a nota 2: " <<endl;
        cin>> nota2;
    cout << "Digite a nota 3: " <<endl;
        cin>> nota3;
    media = (nota1+nota2+nota3)/3;
            
    
    

    return 0;
}

