#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

/*
* 
*/
int main(int argc, char** argv) {
    char nome[20];
    int distancia, tempo;
    float velh;
    cout << "Digite seu Nome: ";
        cin >> nome;
    cout << "Digite a distancia: ";
        cin >> distancia;        
    cout << "Digite o tempo: "; 
        cin >> tempo;
    velh = distancia/(tempo/60.0);
   
    cout << "Ola " << nome << "voce percorreu " << distancia << "km em " << tempo << "min sua velocidade media foi : " << velh << endl;

    return 0;
}