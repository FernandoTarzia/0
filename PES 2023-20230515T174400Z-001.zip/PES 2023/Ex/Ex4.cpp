#include <iomanip>
#include <iostream>
#include <cstdlib>

using namespace std;

int main() 
{
    int n1, n2;
    cout << "Digite o primeiro numero: ";
    cin >> n1;
    cout << "Digite o segundo numero: ";
    cin >> n2;
    if(n1 >= n2)
         cout << "O maior numero e: " << n1;
    else
         cout << "O maior numero e: " << n2;
    return 0;
}