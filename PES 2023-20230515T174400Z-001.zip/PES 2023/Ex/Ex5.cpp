#include <iomanip>
#include <iostream>
#include <cstdlib>

using namespace std;

int main() 
{
    int n1, n2, n3;
    cout << "Digite o primeiro numero: ";
    cin >> n1;
    cout << "Digite o segundo numero: ";
    cin >> n2;
    cout << "Digite o terceiro numero: ";
    cin >> n3;
    if(n1 >= n2 && n1>=n3)
        cout << "O maior numero e: " << n1;
    else if (n2>=n1 && n2>=n3)
        cout << "O maior numero e: " << n2;
    else 
        cout << "O maior numero e: " << n3;
    
         
    
    return 0;
}