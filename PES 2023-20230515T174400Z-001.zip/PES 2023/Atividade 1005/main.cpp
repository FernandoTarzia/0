#include <iostream>
#include <cstring>
#include <cstdlib>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
    string nome;
    int resp,idade;
// Inicio
    cout << " Qual o seu nome: " ;
    getline (cin,nome);
    cout << "Ola " << nome << " eu sou o ChatGPL irei fazer algumas perguntas, voce pode responder?" << endl;
    cout << "Sim - s nao - n : ";
    cin >> resp;
    if (resp == s ) {
        cout << "Tudo bem, vamos prosseguir" << endl;
    }
        else if (resp == n ) {
        cout << "Vou perguntar do mesmo jeito." << endl;
        }
// Pergunta 1
    cout  << "Quantos anos voce tem?" ;
    
    
// Pergunta 2    
    cout << "Qual dessas opcoes voce prefere : ";
    cout << "" ;
    cin >> resp;
    switch (resp)
     case 
            
            
            
            
// Pergunta 3
    
     cout << ""   
    for ()
            
            
            
            
// Pergunta 4          
 
    
// Pergunta 5
    
// Pergunta 6
    
    
           return 0;
}

