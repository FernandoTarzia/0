

#include <cstdlib>
#include <iostream>
using namespace std;


int main(int argc, char** argv) {
    int i = 1, num;
    cout << "Informe um numero: ";
    cin >> num;
    cout << "Os 10 antecessores de " << num << "sao: " <<endl;
    
    do {
        cout << num - i << endl;
        i=i+1;
    } while (i <=10);
    return 0;
}

