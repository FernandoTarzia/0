#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    int i = 1;
    while (i<=100)
    {
        if (i% 10 == 0)
        {
            cout << "contador = " <<i <<endl;
        }
        i = i +1;
    }
    return 0;
}

