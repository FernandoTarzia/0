

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    int opc;
    cout << "Digite 1 para Prato do dia" <<endl;
    cout << "Digite 2 para Lasanha" <<endl;
    cout << "Digite 3 para Picanha Grelhada" <<endl;
    cout << "Digite 4 para Salada Simples" <<endl;
    cin>> opc;
    switch (opc)
    {        
        case 1: 
                cout << "Prato do Dia: 17.00 reais";
                break;
        case 2:
            cout << "Lasanha: 17 reais ";
            break;
        case 3:
            cout << "Picanha Grelhada: 21.90 reais";
            break;
        case 4:
            cout << "Salada Simples: 7.90 reais";
        break;
        default:
            cout << "opcao invalida";
           
    }  
            return 0;
}

