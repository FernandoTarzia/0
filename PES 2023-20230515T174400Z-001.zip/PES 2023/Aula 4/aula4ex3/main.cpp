#include <cstdlib>
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;


int main(int argc, char** argv) {
    int bolo;
    cout << "Escolha uma opcao do cardapio para ver o valor: " << endl;
    cout << "Digite - C - escolher bolo de chocolate." << endl;
    cout << "Digite - B - escolher bolo de banana." << endl;
    cin >> bolo;
    bolo = toupper (bolo);
    switch (bolo)
    {
        case 'C' :
            cout << "O bolo de Chocolate custa R$ 14.00" << endl;
            break;
        case 'B' :
            cout << "O bolo de Banana custa R$ 17.00" << endl;
            break;
 
        default:
            cout << "Opcao Invalida" << endl;
    }        
    return 0;
}