

#include <cstdlib>
#include <iostream>
using namespace std;



int main(int argc, char** argv) {
    int contador = 50;
    while (contador > 0)
    {
        cout << "contador = " << contador  << endl;
        contador = contador - 1;
        cout << "Acabou";
        
    }     
        return 0;
}

