

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   { 
        float media;
    cout << "digite a media do aluno: ";
    cin >> media;
    
    if (media >=0 && media <=0)
    {
        cout << "a media é valida" <<endl;
        if (media>=6)
        {
        cout << " aluno foi  aprovado com media: " << media << endl;
        
        } 
      if  else
        {
   
        cout << "aluno reprovado com media" <<media;
        }
    }
      if  else 
      {
       cout << "a media e invalida";
    }
        
        return 0;
}

