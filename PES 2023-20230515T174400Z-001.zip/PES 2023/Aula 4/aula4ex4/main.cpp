
#include <cstdlib>
#include <iostream>
using namespace std;


int main(int argc, char** argv) {
    int contador = 0;
    while (contador < 5 )
    {
        cout << "Contador = " << contador << endl;
        contador = contador + 1;
        cout << "ACABOU" <<endl;
        
    }
        
    
    
    return 0;
}

