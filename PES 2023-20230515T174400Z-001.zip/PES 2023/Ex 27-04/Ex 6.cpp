
# include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    int valor;
    cout << "Digite o valor: ";
    cin >> valor;
    if (valor > 0) {
    cout << " O valor e positivo";
                    }
    else if  (valor < 0) {
        cout << " O valor e negativo";
    }
    else if (valor == 0) {
     cout << "Valor = Zero"; 
    }
    return 0;
    
}