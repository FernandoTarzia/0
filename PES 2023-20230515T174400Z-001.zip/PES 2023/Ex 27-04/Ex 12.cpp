# include <iostream>
#include <iomanip>
using namespace std;

int main () {
    int num,i;
    float media, soma;
    for (i = 1; i <=20; i++){
        cout << "Digite o " << i << "° numero ";
        cin >> num;
        while  (num < 0) {
            cout << "Numero invalido. Tente novamente ";
        cin >> num;
        }
    cout << fixed << setprecision (2);    
    soma += num;
    }
    media = soma/20;
    cout << "A media foi de " << media;
return 0;
}