#include <iomanip>
#include <iostream>
#include <cstdlib>

using namespace std;

int main() {
    int codigo, quantidade;
    float preco;

    cout << "Cardapio com codigo e preco: " << endl;
    cout << "-------------------------------" << endl;
    cout << "Cachorro Quente  |100| |9,20 | " << endl;
    cout << "Bauru Simples    |101| |12,00| " << endl;
    cout << "Bauru com ovo    |102| |13,00| " << endl;
    cout << "Hamburguer       |103| |10,00| " << endl;
    cout << "Cheeseburguer    |104| |12,00| " << endl;
    cout << "Refrigerante Lata|105| |5,00 | " << endl;
    cout << "Agua             |106| |3,00 | " << endl;
    cout << "-------------------------------" << endl;
    cout << "Digite o codigo do pedido: ";
    cin >> codigo;
    cout << "Quantidade: ";
    cin >> quantidade;
    cout << fixed << setprecision(2);
    if (codigo == 100) {
        preco = quantidade * 9.20;
    } else if (codigo == 101) {
        preco = quantidade * 12.00;
    } else if (codigo == 102) {
        preco = quantidade * 13.00;
    } else if (codigo == 103) {
        preco = quantidade * 10.00;
    } else if (codigo == 104) {
        preco = quantidade * 12.00;
    } else if (codigo == 105) {
        preco = quantidade * 5.00;
    } else if (codigo == 106) {
        preco = quantidade * 3.00;
    } else {
        cout << "Codigo invalido";
    }
    if (codigo >= 100 && codigo <= 106) {
        cout << "codigo da comanda: " << codigo << " quantidade "<< quantidade << " Valor da compra: " << preco << endl;
    }
    return 0;
}