#include <cmath>
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    float area, perimetro,r,pi = 3.14;
    cout << "Digite valor do raio: ";
    cin >> r;
    cout << "O valor do raio e: " << r << endl;
    perimetro = 2*pi*r;
    area = pow (r,2) * pi;
    cout << "O valor da area e: " << area << endl;
    cout << "O valor do perimetro e: " << perimetro << endl;
    return 0;
}
