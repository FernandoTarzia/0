#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    float n1, n2, n3, ma;
    char conceito;
    cout << fixed << setprecision(2);
    cout << "Digite a primeira nota: ";
    cin >> n1;
    cout << "Digite a segunda nota: ";
    cin >> n2;
    cout << "Digite a terceira nota: ";
    cin >> n3;
    ma = (n1 + (n2 * 2) + (n3 * 3)) / 6;
    if (ma >= 9) {
        conceito = 'A';
    } else if (ma >= 7.5 && ma < 9) {
        conceito = 'B';
    } else if (ma >= 6 && ma < 7.5) {
        conceito = 'C';
    } else if (ma >= 4 && ma < 6) {
        conceito = 'D';
    } else if (ma < 4) {
        conceito = 'E';
    }
    if (ma >= 6) {
        cout << "Aluno aprovado com media de " << ma << " conceito " << conceito;
    } else {
        cout << "Aluno reprovado com media de " << ma << " conceito " << conceito;
    }
    return 0;
}