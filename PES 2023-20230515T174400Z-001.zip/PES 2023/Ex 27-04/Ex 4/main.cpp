#include <iomanip>
# include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char produto [30];
    float desconto, valor , valorf;
    cout << fixed << setprecision (2);
    cout << "Digite o nome do produto: ";
    cin >> produto;
    cout << "Digite valor do produto: ";
    cin >> valor;
    desconto = valor * 0.13;
    valorf = valor - desconto;
    cout << "Desconto: " << desconto << endl;
    cout << "O valor final e: " << valorf << endl; 
    return 0;
}

