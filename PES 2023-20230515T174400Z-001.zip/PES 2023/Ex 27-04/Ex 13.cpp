# include <iostream>
#include <iomanip>
using namespace std;

int main () {
    int num,i,cont;
    float media, soma;
    for (i = 1; i <=20; i++){
        cout << "Digite o " << i << "° numero ";
        cin >> num;
    if (num % 2 == 0 ){
        cout << fixed << setprecision (2);
        soma += num;
        cont ++;
    }
        }    
    media = soma / cont ;
    cout << "A media dos numeros pares foi de " << media;
return 0;
}