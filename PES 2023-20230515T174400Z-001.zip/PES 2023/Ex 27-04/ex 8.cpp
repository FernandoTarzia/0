#include <iostream>
#include <iomanip>
 using namespace std;
 int main  () {
  float p,h;
  char sexo;
   cout << "Calculo de Peso Ideal" << endl;
   cout << fixed << setprecision (2);
   cout << "Digite a sua altura: ";
   cin >> h;
   cout << "Digite 'M' para o sexo masculino ou 'F' para o sexo feminino: " << endl;
   cin >> sexo;
   if (sexo == 'm') {
    p = (72.7 * h) - 58;
   } else if (sexo == 'f')  {
    p = (62.1 * h) - 44.7;
   }
   
    else {
    
        cout << "Sexo inválido. Insira 'M' para masculino ou 'F' para feminino.";
        return 1;}
 cout << "O sexo escolhido foi: " << sexo << endl << "altura: " << h << endl << "peso ideal: " << p << endl;   
 return 0;
 }

