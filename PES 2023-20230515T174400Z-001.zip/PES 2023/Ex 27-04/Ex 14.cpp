# include <iomanip>

using namespace std;
int main () {
    float sal, medsal, maiorsal;
    int f,medf,i;
    for (i=1 ; i <=15; i++) {
        cout << fixed << setprecision (2);
        cout << "Digite salario do " << i << "° habitante: ";
        cin >> sal;
        cout << "Digite o numero de filhos(as) do " << i << "° habitante: ";
        cin >> f;
        medsal += sal;
        medf += f;        
    if (sal > maiorsal) {
        maiorsal = sal;
     }
    }
    medsal /= 15;
    medf /= 15;
    cout << "Media do salario da populacao: " << medsal << endl;
    cout << "Media do numero de filhos da populacao: " << medf << endl;
    cout << "Maior salario da populacao: " << maiorsal << endl;

return 0;

}