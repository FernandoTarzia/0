#include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char nome [20];
    cout << "Digite seu nome: ";
    cin >> nome;
    cout << "Meu nome e: " << nome << endl;
    cout << "Sou do curso de Sistemas de Informacao" << endl;
    cout << "Estou no primeiro ano" << endl;
    cout << "Gosto de programacao" << endl;
    return 0;
}

