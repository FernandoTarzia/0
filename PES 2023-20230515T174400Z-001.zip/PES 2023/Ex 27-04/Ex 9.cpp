#include <iostream>

using namespace std;
int main (){
    int num;
    cout << "Digite um numero: ";
    cin >> num;
    if (num % 2 == 0){
        cout << "Numero e par "; }
    else {
        cout << "Numero e impar";
    }
return 0;
}
