
#include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    cout << "Sou calouro de BSI";
    return 0;
}

