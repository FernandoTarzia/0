#include <iostream>

using namespace std;

int main () {
    int num,i,contador;
    for  ( i=1; i <= 15; i++) {
    cout << "Digite " << i << "° numero";
    cin >> num;
    if (num < 0 ) {
        
     }
    }
    cout << "Foram digitados " << contador << " numeros negativos ";

return 0;
}
