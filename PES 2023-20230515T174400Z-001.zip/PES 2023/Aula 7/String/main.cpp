
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <cstring>
using namespace std;


int main(int argc, char** argv) {
    string nome ;
    float n1,n2,n3,med;
    
    cout << "Digite seu nome completo: " ;
    getline (cin,nome);
    cout << "Digite nota 1: ";
    cin >> n1;
    cout << "Digite nota 2: ";
    cin >> n2;
    cout <<  "Digite nota 3: ";
    cin >> n3;
    cout << fixed << setprecision (2);
    med = (n1+n2+n3)/3;
    cout << "Sua media e: " << med << endl;
   
    return 0;
}

