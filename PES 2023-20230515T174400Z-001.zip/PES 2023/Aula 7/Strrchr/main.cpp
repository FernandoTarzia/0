#include <cstring>
#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    char texto [] = "Teste";
    char *ptr;
    cout << "Procurando por 's' no texto: \n\n " << texto << endl << endl;
    ptr=strrchr (texto, 's');
    if (*ptr) {
        cout << "A letra s apareceu a primeira vez na posicao: " << ptr-texto+1;
    }
    else {
        cout << "Letra nao encontrada no texto.";
    }
    return 0;
}

