# include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char palavra [20];
    cout << "Este exemplo substitui caracter de  uma palavra." << endl;
    cout << "Digite uma palavra: ";
    cin >> palavra;
    cout << "Substituindo " << strset(palavra,'*');
    
    return 0;
}

