# include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char palavra [20];
    cout << "Este exemplo inverte a palavra." << endl;
    cout << "Digite uma palavra: ";
    cin >> palavra;
    cout << "A palavra " << palavra << " invertida fica: " << strrev (palavra);
    
    return 0;
}

