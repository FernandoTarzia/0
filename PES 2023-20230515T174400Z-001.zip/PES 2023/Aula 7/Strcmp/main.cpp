#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char palavra [20], palavra2 [20];
    cout << "Digite a palavra 1: " << endl;
    cin >> palavra;
    cout << "Digite a palavra 2: " << endl;
    cin >> palavra2;
    if (strcmp (palavra,palavra2) == 0) {
        cout << "As palavras sao iguais";
    }
    else {
        cout << "As palavras sao diferentes";
    }
    return 0;
}
