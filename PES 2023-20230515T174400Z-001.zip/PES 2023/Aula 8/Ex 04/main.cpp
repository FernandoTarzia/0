#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
    const int tamanho = 5;
   float notas [tamanho], media = 0; 
   int i=0,j;
   cout << setprecision (2);
   do{
       if (i >= tamanho){
       cout << "Buffer lotado." << endl;
       i++;
       break;
       }
      cout << "Digite a nota do aluno " << (i+1) << ": "; 
       cin >> notas [i];
   } while (notas[i++] >= 0);
   
   i--;
   for (j = 0; j < 1; j++) {
       media += notas [j];
   } 
  cout << "Media das notas: " << (media/tamanho) << endl; 
    return 0;
}
