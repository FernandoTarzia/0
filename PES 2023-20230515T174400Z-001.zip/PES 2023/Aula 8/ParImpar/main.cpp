#include <iostream>

using namespace std;

int main(){
    int numeros[15], i;
    
    for(int i = 0; i < 15; i++){
        cout << "Digite um numero: ";
        cin >> numeros[i];
    }
    
    for(int i = 0; i < 15; i++){
        if(numeros[i] % 2 == 0){
            cout << numeros[i] << " - PAR" << endl;
        }else{
            cout << numeros[i] << " - IMPAR" << endl;
        }
    }
    
    return 0;
}