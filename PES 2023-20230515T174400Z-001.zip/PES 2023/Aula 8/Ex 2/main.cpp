#include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    int vetor [5],i;
    
    for (i = 0; i < 5; i++) { 
    cout << "Digite um numero para armazenar na posicao: " <<  (i) << " do vetor "  << endl;
    cin >> vetor [i];
    }
    cout << "" << endl << endl;
    for (int i = 0; i < 5; i++) {
        cout << vetor [i] << endl << endl;
    }
    return 0;
}

