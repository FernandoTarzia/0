

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
int main(int argc, char** argv) {
    char nome [30];
    int sl,imp;
    cout << "Digite seu nome: ";
    cin >> nome;
    cout << "Dite o salario: ";
    cin >> sl;
    {
        {
        if  (sl < 2000);
            cout << nome << "voce tem isencao de pagamento do IRPF" << endl;  
    }
            {
        if  (sl >= 2000 && sl < 3000);
                
        imp = (sl * 0.15);
        cout << nome << "voce devera pagar: " << imp << " de IRPF " << endl;
        
        
        
            } 
       
        
    }
    
    return 0;
}

