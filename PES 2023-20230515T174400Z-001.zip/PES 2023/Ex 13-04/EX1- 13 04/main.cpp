
#include <cstdlib>
#include <iostream>
using namespace std;


int main(int argc, char** argv) {
    int opc;
    cout << "Digite 1 para Sao Paulo" << endl;
    cout << "Digite 2 para Santos" << endl;
    cout << "Digite 3 para Palmeiras" << endl;
    cout << "Digite 4 para Corinthians" << endl;
    cin >> opc;
    switch (opc)
    {
        case 1 :
            cout << "Time escolhido: Sao Paulo" << endl;
            break;
        case 2 :
            cout << "Time escolhido: Santos" << endl;
            break;
        case 3:
            cout << "Time escolhido: Palmeiras" << endl; 
            break;
        case 4 :
            cout << "Time escolhido: Corinthians" << endl;
            break;
        default:
            cout << "Codigo Invalido" << endl;
    }        
    return 0;
}

