#include<iostream>
#include <cstdlib>
using namespace std;


int main(int argc, char** argv) {
    int i,num,contador = 1;
do {
    cout << "insira um numero" << endl;
    cin >> num;
    if (num !=0)
        contador = contador +1;
} while (num !=0);
    cout << "Foram digitados " << contador << " numeros" << endl; 
    
        return 0; 
}
        
  


