#include <iostream>
#include <cstdlib>
#include <locale>

using namespace std;


int main(int argc, char** argv) {
    setlocale (LC_ALL, "portuguese");
    unsigned int idade;
    cout << "Informe a sua idade: " << endl;
    cin >> idade;
    cout << "A sua idade é: " << idade << endl;
    return 0;
}

