#include <iomanip>
#include <cstdlib>
#include <iostream>
using namespace std;


int main(int argc, char** argv) {
    int idade = 19;
    long long int cpf = 22345500000458791;
    float salario = 1248.50;
    double pi = 3.1415249999998091;
    char sexo = 'f';
    char nome [50] = "Linguagem C";
    cout << "Teste com os tipos de variaveis:" << endl;
    cout << "Idade: " << idade << endl;
    cout << "CPF: " << cpf << endl;
    cout << fixed << setprecision (2);
    cout << "Salario: " << salario << endl;
    cout << fixed << setprecision (7);
    cout << " Pi: " << pi << endl;
    cout << "Sexo: " << sexo << endl;
    cout << "Nome: " << nome << endl;
    
    return 0;
}

