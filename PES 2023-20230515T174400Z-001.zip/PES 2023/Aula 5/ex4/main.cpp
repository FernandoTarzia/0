#include <iostream>
#include <cctype>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    char digito;
    cout << "Digite uma letra: ";
    cin >> digito;
    
    digito = toupper (digito);
    
    cout << "A letra digitada foi: " << digito << endl;
    return 0;
}

