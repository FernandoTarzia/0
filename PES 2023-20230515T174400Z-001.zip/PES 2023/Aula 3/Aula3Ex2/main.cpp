

/* 

 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int num1,num2;
    cout << "Operadores Lógicos" <<endl;
    cout << "Digite 2 Números" <<endl;
        cin >> num1 >>num2;
    cout << "A Negação do primeiro num é: " << !num1 <<endl;
    cout << "A op. And entre o primeiro e segundo num é: " <<(num1 && num2)<< endl;
    cout << "A op. Or entre o primeiro e segundo num é: " << (num1||num2)<< endl;
            

    return 0;
}

