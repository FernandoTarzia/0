
#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int golsSaoPaulo, golsPalmeiras;
    cout <<"\n*** Placar Sao Paulo x Palmeiras ***\n";
    cout << "Digite a quantidade de gols Sao Paulo: ";
        cin>> golsSaoPaulo;
    cout<< "\nDigite a quantidade de gols do Palmeiras: " <<endl; 
    cin>> golsPalmeiras;
    if (golsSaoPaulo > golsPalmeiras);
    cout << "A festa e tricolor" <<endl;
    return 0;
}

