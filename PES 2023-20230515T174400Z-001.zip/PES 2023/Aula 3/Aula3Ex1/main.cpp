

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <locale>


using namespace std;

/*
 * 
 */

int main(int argc, char ** argv) {
    setlocale (LC_ALL,"portuguese");
     float num1,num2,num3,soma,subtracao,divisao,multiplicacao;
     int resto,num4,num5; 
        cout << "Este programa irá executar algumas operações matemáticas" <<endl;
        cout << "cinco números serão necessários." << endl <<endl;
        cout << "digite o primeiro número: " <<endl;
     cin >> num1;
        cout << "digite o segundo número: " <<endl;
     cin >> num2;
        cout<< "digite o terceiro número: " <<endl;
     cin >> num3;
        cout << "digite o quarto número: " <<endl;
     cin >> num4;
        cout << "digite o quinto número: " <<endl;
     cin >> num5;   
     soma = num1+num2;
        cout << " A soma do primeiro e segundo número é: " <<soma <<endl;
     subtracao = num3-num1;
        cout << "A subtração do terceiro e primeiro número é: " <<subtracao <<endl;
     divisao = num2/num1;
        cout << "A divisão do segundo número pelo primeiro num é: " << setprecision (2) <<divisao <<endl;
     multiplicacao = num1 * num2;
        cout << "A multiplicação do primeiro número pelo segundo número é: " <<multiplicacao <<endl;
     resto = num4%num5;
        cout << "O resto da divisão entre o quarto e quinto número é: " <<resto <<endl;
             
     
      
    
     return 0;
}
    

