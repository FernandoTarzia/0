
#include <iostream>
#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    int i;
    for (i = 3; i <= 100; i+=3)
        cout << i << endl;
    return 0;
}
